// const mmS = document.getElementByClassName('mms')[0]
// const menu = document.getElementByClassName('menu')[0]

// mmS.addEventListener('click',()=>{
// menu.classList.toggle('active')
// })
function openNav() {
document.getElementById("myNav").style.height = "70%";
document.getElementById("main").style.marginTop = "325px";
}
function closeNav() {
document.getElementById("myNav").style.height = "0%";
 document.getElementById("main").style.marginTop = "0%";
}
